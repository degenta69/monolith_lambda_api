// authorizer/index.ts
var handler = (event, context) => {
  try {
    console.log(event, context);
    return {
      isAuthorized: true,
      context: {
        me: "new"
      }
    };
  } catch (error) {
  }
};
export {
  handler
};
