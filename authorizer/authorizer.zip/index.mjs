import {
  routePermissionContainer_default
} from "./chunks/chunk-26EYTZ3I.mjs";
import "./chunks/chunk-NEHRGNBA.mjs";

// authorizer/index.ts
var handler = (event, context) => {
  try {
    console.log(event, context, routePermissionContainer_default);
    return {
      isAuthorized: true,
      context: {
        me: "new"
      }
    };
  } catch (error) {
  }
};
export {
  handler
};
