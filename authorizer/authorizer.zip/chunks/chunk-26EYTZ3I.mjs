// authorizer/routes/routePermissionContainer.ts
var AdminRoutes = [
  "/test/encrypt" /* /test/encrypt */
];
var SuperAdminRoutes = [
  "/test/decrypt" /* /test/decrypt */
];
var SupportRoutes = [
  "/test/user/update" /* /test/user/update */,
  "/test/user/delete" /* /test/user/delete */
];
var UserRoutes = [];
var AllRoutes = [
  "/test/user/add" /* /test/user/add */
];
var route_permission_container = Object.freeze({
  [8 /* SuperAdmin */]: AllRoutes.concat(...AdminRoutes, ...SuperAdminRoutes, ...SupportRoutes, ...UserRoutes),
  [4 /* Admin */]: AllRoutes.concat(...AdminRoutes, ...SupportRoutes, ...UserRoutes),
  [2 /* Support */]: AllRoutes.concat(...SupportRoutes, ...UserRoutes),
  [1 /* User */]: AllRoutes.concat(...UserRoutes)
});
var routePermissionContainer_default = route_permission_container;

export {
  routePermissionContainer_default
};
