// authorizer/enums/roleEnum.ts
var Role = /* @__PURE__ */ ((Role2) => {
  Role2[Role2["User"] = 1] = "User";
  Role2[Role2["Support"] = 2] = "Support";
  Role2[Role2["Admin"] = 4] = "Admin";
  Role2[Role2["SuperAdmin"] = 8] = "SuperAdmin";
  Role2[Role2["ALL"] = 16] = "ALL";
  return Role2;
})(Role || {});

// authorizer/enums/routeEnums.ts
var RouteEnums = /* @__PURE__ */ ((RouteEnums2) => {
  RouteEnums2["/test/user/add"] = "/test/user/add";
  RouteEnums2["/test/user/delete"] = "/test/user/delete";
  RouteEnums2["/test/user/update"] = "/test/user/update";
  RouteEnums2["/test/decrypt"] = "/test/decrypt";
  RouteEnums2["/test/encrypt"] = "/test/encrypt";
  return RouteEnums2;
})(RouteEnums || {});

export {
  Role,
  RouteEnums
};
