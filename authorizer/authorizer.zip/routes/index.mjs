import {
  routePermissionContainer_default
} from "../chunks/chunk-26EYTZ3I.mjs";
import "../chunks/chunk-NEHRGNBA.mjs";
export {
  routePermissionContainer_default as route_permission_container
};
