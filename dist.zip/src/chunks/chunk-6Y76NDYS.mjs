import {
  handlerErrorReturn
} from "./chunk-VOZRCC2V.mjs";

// src/middleware/applyMiddleware.ts
var applyMiddleware = (handler, middlewares) => {
  return middlewares.reverse().reduce((wrapped, middleware) => middleware(wrapped), handler);
};

// src/middleware/validationMiddleware.ts
var validationMiddleware = (schema) => {
  return (handler) => {
    return async (injector, event, context) => {
      try {
        let validationResult = await schema.validate(
          JSON.parse(event.body || "{}"),
          { abortEarly: true }
        );
        event.body = validationResult;
        console.log(validationResult, "validationResult");
        return await handler(injector, event, context);
      } catch (error) {
        injector.logger.error(error);
        return {
          statusCode: 400,
          body: JSON.stringify(
            handlerErrorReturn(parseInt(error.message))
          )
        };
      }
    };
  };
};

export {
  applyMiddleware,
  validationMiddleware
};
