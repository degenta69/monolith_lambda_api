import {
  applyMiddleware,
  validationMiddleware
} from "./chunk-6Y76NDYS.mjs";
import {
  addUserSchema,
  idValidateSchema,
  updateUserSchema
} from "./chunk-B5IRZ4AL.mjs";
import {
  handlerErrorReturn
} from "./chunk-VOZRCC2V.mjs";

// src/handlers/addUserHandler.ts
var rawAddUserHandler = async (DC, event, context) => {
  let body = event.body;
  try {
    let result = await DC.db_client.users.create({
      data: {
        email: body.email,
        name: body.name,
        phoneNumber: body.phoneNumber,
        role: body.role
      }
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `new user added`, user: result })
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify(
        handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */)
      )
    };
  }
};
var addUserHandler = applyMiddleware(rawAddUserHandler, [
  validationMiddleware(addUserSchema)
]);

// src/handlers/updateUserHandler.ts
var rawUpdateUserHandler = async (DC, event, context) => {
  let body = event.body;
  try {
    let { id, ...restBody } = body;
    const result = await DC.db_client.users.update({
      where: {
        id
      },
      data: restBody
    });
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `updated user successfully`,
        user: result
      })
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify(
        handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */)
      )
    };
  }
};
var updateUserHandler = applyMiddleware(rawUpdateUserHandler, [
  validationMiddleware(updateUserSchema)
]);

// src/handlers/deleteUserHandler.ts
var rawDeleteUserHandler = async (DC, event, context) => {
  let body = event.body;
  try {
    const result = await DC.db_client.users.delete({
      where: {
        id: body.id
      }
    });
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `deleted user successfully`,
        user: result
      })
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify(handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};
var deleteUserHandler = applyMiddleware(rawDeleteUserHandler, [
  validationMiddleware(idValidateSchema)
]);

// src/handlers/decryptHandler.ts
var decryptHandler = async (DC, event, context) => {
  let body = event.body;
  if (!body) {
    return {
      statusCode: 400,
      body: JSON.stringify(handlerErrorReturn(12 /* INVALID_BODY */))
    };
  }
  try {
    let result = await DC.Cryptography.decrypt(body);
    DC.logger.log(result, "decrypt request handler");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `decrypted successfully`, user: result })
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify(handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};

// src/handlers/encryptHandler.ts
var encryptHandler = async (DC, event, context) => {
  let body = event.body && JSON.parse(event.body);
  if (!body) {
    return {
      statusCode: 400,
      body: JSON.stringify(handlerErrorReturn(12 /* INVALID_BODY */))
    };
  }
  try {
    let result = await DC.Cryptography.encrypt(body.data, body?.key);
    DC.logger.log(result, "encrypt request handler");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `encrypted successfully`, user: result })
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify(handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};

export {
  addUserHandler,
  updateUserHandler,
  deleteUserHandler,
  decryptHandler,
  encryptHandler
};
