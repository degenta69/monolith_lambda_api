import {
  addUserSchema,
  idValidateSchema,
  updateUserSchema
} from "./chunk-5FQOEDPE.mjs";
import {
  createStandardError
} from "./chunk-CQZB46HZ.mjs";

// src/models/apiResponses/foundation.ts
var CreateSuccess = (data) => ({ success: true, data });
var CreateFailure = (data) => ({ success: false, data });

// src/handlers/addUserHandler/validateAddUserRequest.ts
var validateAddUserRequest = async (user, Prisma) => {
  let result = await addUserSchema.validate(user, { stripUnknown: true, strict: true, abortEarly: true });
  console.log(result, "validation result");
  let userCount = await Prisma.users.count({
    where: {
      email: user.email,
      phoneNumber: user.phoneNumber ?? ""
    }
  });
  let doesUserExist = userCount > 0;
  if (doesUserExist) {
    return CreateFailure(
      createStandardError(14 /* USER_ALREADY_EXIST */)
    );
  }
  return CreateSuccess(user);
};

// src/handlers/addUserHandler/addUser.ts
var addUser = async (user, Prisma) => {
  let result = Prisma.users.create({
    data: {
      email: user.email && user.email,
      name: user.name && user.name,
      role: user.role,
      phoneNumber: user.phoneNumber && user.phoneNumber
    }
  });
  return result;
};

// src/handlers/addUserHandler/index.ts
var addUserHandler = async (DC, userToAdd) => {
  let validationResult = await validateAddUserRequest(userToAdd, DC.db_client);
  if (!validationResult.success) {
    return {
      statusCode: 400 /* BAD_REQUEST_400 */,
      body: validationResult.data
    };
  }
  let addedUser = await addUser(validationResult.data, DC.db_client);
  return {
    statusCode: 200 /* OK_200 */,
    body: { user: addedUser }
  };
};

// src/handlers/updateUserHandler/validateUpdateUserRequest.ts
var validateUpdateUserRequest = async (user, Prisma) => {
  let result = await updateUserSchema.validate(user, { stripUnknown: true, strict: true, abortEarly: true });
  console.log(result, "validation result");
  let doesUserExist = await Prisma.users.findUnique({
    where: {
      id: user.id
    }
  });
  if (!Boolean(doesUserExist)) {
    return CreateFailure(
      createStandardError(15 /* USER_ID_NOT_EXIST */)
    );
  }
  return CreateSuccess(user);
};

// src/handlers/updateUserHandler/updateUser.ts
var updateUser = async (user, Prisma) => {
  let { id, ...restData } = user;
  const result = await Prisma.users.update({
    where: {
      id
    },
    data: restData
  });
  return result;
};

// src/handlers/updateUserHandler/index.ts
var updateUserHandler = async (DC, userData) => {
  let validationResult = await validateUpdateUserRequest(userData, DC.db_client);
  if (!validationResult.success) {
    return {
      statusCode: 400 /* BAD_REQUEST_400 */,
      body: validationResult.data
    };
  }
  let addedUser = await updateUser(userData, DC.db_client);
  return {
    statusCode: 200 /* OK_200 */,
    body: { user: addedUser }
  };
};

// src/handlers/deleteUserHandler/validateDeleteUserRequest.ts
var validateDeleteUserRequest = async (user, Prisma) => {
  let result = await idValidateSchema.validate(user, { stripUnknown: true, strict: true, abortEarly: true });
  console.log(result, "validation result");
  let doesUserExist = await Prisma.users.findUnique({
    where: {
      id: user.id
    }
  });
  if (!Boolean(doesUserExist)) {
    return CreateFailure(
      createStandardError(15 /* USER_ID_NOT_EXIST */)
    );
  }
  return CreateSuccess(user);
};

// src/handlers/deleteUserHandler/deleteHandler.ts
var deleteUser = (userID, Prisma) => {
  const result = Prisma.users.delete({
    where: {
      id: userID.id
    }
  });
  return result;
};

// src/handlers/deleteUserHandler/index.ts
var deleteUserHandler = async (DC, userID) => {
  let validationResult = await validateDeleteUserRequest(userID, DC.db_client);
  if (!validationResult.success) {
    return {
      statusCode: 400 /* BAD_REQUEST_400 */,
      body: validationResult.data
    };
  }
  await deleteUser(userID, DC.db_client);
  return {
    statusCode: 204 /* NO_CONTENT_204 */,
    body: {}
  };
};

// src/handlers/decryptHandler.ts
var decryptHandler = async (DC, event, context) => {
  let body = event.body;
  if (!body) {
    return {
      statusCode: 400,
      body: createStandardError(12 /* INVALID_BODY */)
    };
  }
  try {
    let result = await DC.cryptography.decrypt(body);
    DC.logger.log(result, "decrypt request handler");
    return {
      statusCode: 200,
      body: { message: `decrypted successfully`, decrypted: result }
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: createStandardError(2 /* INTERNAL_SERVER_ERROR */)
    };
  }
};

// src/handlers/encryptHandler.ts
var encryptHandler = async (DC, event, context) => {
  let body = event.body && JSON.parse(event.body);
  if (!body) {
    return {
      statusCode: 400,
      body: createStandardError(12 /* INVALID_BODY */)
    };
  }
  try {
    let result = await DC.cryptography.encrypt(body.data, body?.key);
    DC.logger.log(result, "encrypt request handler");
    return {
      statusCode: 200,
      body: { message: `encrypted successfully`, encrypted: result }
    };
  } catch (error) {
    DC.logger.error(error);
    return {
      statusCode: 500,
      body: createStandardError(2 /* INTERNAL_SERVER_ERROR */)
    };
  }
};

export {
  addUserHandler,
  updateUserHandler,
  deleteUserHandler,
  decryptHandler,
  encryptHandler
};
