import {
  Role,
  getAllKeysFromEnum
} from "./chunk-VOZRCC2V.mjs";

// src/schema/addUserSchema.ts
import yup from "yup";
var addUserSchema = yup.object({
  email: yup.string().email(4 /* EMAIL_NOT_VALID */.toString()).required(7 /* USER_EMAIL_REQUIRED */.toString()),
  name: yup.string().min(5, 11 /* USER_NAME_MAX_15 */.toString()).max(15, 11 /* USER_NAME_MAX_15 */.toString()).required(8 /* USER_NAME_REQUIRED */.toString()),
  phoneNumber: yup.string().matches(
    /^(\+91|91)\s?\-?\d+/,
    5 /* PHONE_NUMBER_NOT_VALID */.toString()
  ),
  role: yup.mixed().oneOf(getAllKeysFromEnum(Role)).required(9 /* USER_ROLE_REQUIRED */.toString())
});

// src/schema/idValidateSchema.ts
import yup2 from "yup";
var idValidateSchema = yup2.object({
  id: yup2.string().required(13 /* ID_IS_REQUIRED */.toString())
});

// src/schema/updateUserSchema.ts
import yup3 from "yup";
var updateUserSchema = idValidateSchema.concat(
  yup3.object({
    email: yup3.string().email(4 /* EMAIL_NOT_VALID */.toString()),
    name: yup3.string().min(5, 11 /* USER_NAME_MAX_15 */.toString()).max(15, 11 /* USER_NAME_MAX_15 */.toString()),
    phoneNumber: yup3.string().matches(
      /^(\+91|91)\s?\-?\d+/,
      5 /* PHONE_NUMBER_NOT_VALID */.toString()
    ),
    role: yup3.mixed().oneOf(getAllKeysFromEnum(Role))
  })
);

export {
  addUserSchema,
  idValidateSchema,
  updateUserSchema
};
