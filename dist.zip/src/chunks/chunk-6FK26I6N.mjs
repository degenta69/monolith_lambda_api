// src/models/enums/roleEnum.ts
var Role = /* @__PURE__ */ ((Role2) => {
  Role2[Role2["User"] = 1] = "User";
  Role2[Role2["Support"] = 2] = "Support";
  Role2[Role2["Admin"] = 4] = "Admin";
  Role2[Role2["SuperAdmin"] = 8] = "SuperAdmin";
  return Role2;
})(Role || {});

// src/resources/apiErrorResponseMessages.ts
var responseErrorMessage = {
  [1 /* OK */]: "OK",
  [2 /* INTERNAL_SERVER_ERROR */]: "An unexpected error occurred on the server.",
  [3 /* RESOURCE_NOT_FOUND */]: "Requested resource not found.",
  [4 /* EMAIL_NOT_VALID */]: "Invalid email format.",
  [5 /* PHONE_NUMBER_NOT_VALID */]: "Invalid phone number format.",
  [6 /* BAD_ADD_USER_REQUEST */]: "Invalid data provided for user creation.",
  [7 /* USER_EMAIL_REQUIRED */]: "User email is mandatory.",
  [8 /* USER_NAME_REQUIRED */]: "Username is required.",
  [9 /* USER_ROLE_REQUIRED */]: "User role is required.",
  [10 /* USER_NAME_MIN_5 */]: "Username must be at least 5 characters long.",
  [11 /* USER_NAME_MAX_15 */]: "Username cannot exceed 15 characters.",
  [12 /* INVALID_BODY */]: "Request body is invalid or missing.",
  [13 /* ID_IS_REQUIRED */]: "Unique identifier (ID) is required.",
  [14 /* USER_ALREADY_EXIST */]: "User already exist.",
  //Prisma messages
  ["P1013" /* InvalidDatabaseString */]: "Invalid database configuration provided.",
  ["P1014" /* UnderlyingModelDoesNotExist */]: "The requested database model does not exist.",
  ["P1015" /* UnsupportedDatabaseFeatures */]: "The database version does not support required features.",
  ["P1016" /* IncorrectParameterCount */]: "Incorrect number of parameters provided for the query.",
  ["P1017" /* ConnectionClosed */]: "Database connection has been closed unexpectedly.",
  ["P2000" /* ValueTooLong */]: "Provided value exceeds the maximum allowed length.",
  ["P2001" /* RecordNotFound */]: "The requested record could not be found.",
  ["P2002" /* UniqueConstraintFailed */]: "A unique constraint violation occurred.",
  ["P2003" /* ForeignKeyConstraintFailed */]: "A foreign key constraint violation occurred.",
  ["P2004" /* ConstraintFailed */]: "A database constraint violation occurred.",
  ["P2005" /* InvalidStoredValue */]: "Invalid value stored in the database for a field.",
  ["P2006" /* InvalidFieldValue */]: "Invalid value provided for a field.",
  ["P2007" /* DataValidationError */]: "Data validation error occurred.",
  ["P2008" /* QueryParseFailure */]: "Failed to parse the provided query.",
  ["P2009" /* QueryValidationFailure */]: "Query validation failed.",
  ["P2010" /* RawQueryFailed */]: "Execution of raw query failed.",
  ["P2011" /* NullConstraintViolation */]: "A null constraint violation occurred.",
  ["P2012" /* MissingRequiredValue */]: "A required value is missing.",
  ["P2013" /* MissingRequiredArgument */]: "A required argument is missing.",
  ["P2014" /* RelationViolation */]: "A relation constraint violation occurred.",
  ["P2015" /* RelatedRecordNotFound */]: "A related record could not be found.",
  ["P2016" /* QueryInterpretationError */]: "Error occurred while interpreting the query.",
  ["P2017" /* RecordsNotConnected */]: "Required records are not connected.",
  ["P2018" /* RequiredConnectedRecordsNotFound */]: "Required connected records were not found.",
  ["P2019" /* InputError */]: "Invalid input provided.",
  ["P2020" /* ValueOutOfRange */]: "Provided value is out of the acceptable range.",
  ["P2021" /* TableDoesNotExist */]: "The specified table does not exist in the database.",
  ["P2022" /* ColumnDoesNotExist */]: "The specified column does not exist in the database.",
  ["P2023" /* InconsistentColumnData */]: "Inconsistent data found in database column.",
  ["P2024" /* ConnectionPoolTimeout */]: "Database connection pool timeout occurred.",
  ["P2025" /* RecordRequiredButNotFound */]: "A required record was not found.",
  ["P2026" /* UnsupportedFeature */]: "The requested feature is not supported by the current database provider.",
  ["P2027" /* MultipleErrors */]: "Multiple errors occurred during query execution.",
  ["P2028" /* TransactionApiError */]: "An error occurred in the transaction API.",
  ["P2029" /* QueryParameterLimitExceeded */]: "Query parameter limit has been exceeded.",
  ["P2030" /* FullTextIndexNotFound */]: "Required full-text index not found.",
  ["P2031" /* MongoDbReplicaSetRequired */]: "MongoDB replica set is required but not configured.",
  ["P2033" /* NumberOutOfRange */]: "Numeric value is out of the supported range.",
  ["P2034" /* TransactionWriteConflict */]: "A write conflict occurred during transaction.",
  ["P2035" /* AssertionViolation */]: "An assertion violation occurred in the database.",
  ["P2036" /* ExternalConnectorError */]: "An error occurred in an external connector.",
  ["P2037" /* TooManyDatabaseConnections */]: "Maximum number of database connections exceeded."
};

export {
  Role,
  responseErrorMessage
};
