import {
  addUserHandler,
  decryptHandler,
  deleteUserHandler,
  encryptHandler,
  updateUserHandler
} from "./chunk-SU5NRFYH.mjs";

// src/routes/routeContainer.ts
var route_container = Object.freeze({
  ["/test/user/add" /* /test/user/add */]: addUserHandler,
  ["/test/user/delete" /* /test/user/delete */]: deleteUserHandler,
  ["/test/user/update" /* /test/user/update */]: updateUserHandler,
  ["/test/decrypt" /* /test/decrypt */]: decryptHandler,
  ["/test/encrypt" /* /test/encrypt */]: encryptHandler
});
var routeContainer_default = route_container;

export {
  routeContainer_default
};
