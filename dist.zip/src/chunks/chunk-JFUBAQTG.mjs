import {
  addUserHandler,
  decryptHandler,
  deleteUserHandler,
  encryptHandler,
  updateUserHandler
} from "./chunk-XNM33D3Y.mjs";
import {
  attachHandler
} from "./chunk-CQZB46HZ.mjs";

// src/routes/routeContainer.ts
var ROUTE_CONTAINER = {
  "/test/user/add": attachHandler(addUserHandler),
  "/test/user/delete": attachHandler(deleteUserHandler),
  "/test/user/update": attachHandler(updateUserHandler),
  "/test/decrypt": attachHandler(decryptHandler),
  "/test/encrypt": attachHandler(encryptHandler)
};
var routeContainer_default = ROUTE_CONTAINER;

export {
  routeContainer_default
};
