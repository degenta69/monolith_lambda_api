import {
  responseErrorMessage
} from "./chunk-6FK26I6N.mjs";

// src/utility/common.ts
function hasRequiredFields(obj, ...fields) {
  const flatFields = fields.flat();
  return flatFields.every((field) => obj.hasOwnProperty(field));
}
var getAllKeysFromEnum = (enumObject) => {
  return Object.values(enumObject).filter((value) => typeof value === "number");
};
var parseEventBody = (stringifiedBody) => {
  return JSON.parse(stringifiedBody ?? "{}");
};

// src/utility/createStandardError.ts
var createStandardError = (responseCode, extra) => ({
  message: responseErrorMessage[responseCode],
  responseCode,
  extra
});

// src/utility/errorCatcher.ts
import { Prisma } from "@prisma/client";
var errorCatcher = (Func) => {
  return async (DC, event, context) => {
    try {
      return await Func(DC, event, context);
    } catch (error) {
      DC.logger.log(JSON.stringify(error));
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        if (error.code === "P2002") {
          return {
            statusCode: 409 /* CONFLICT_409 */,
            body: createStandardError(error.code)
          };
        }
        return {
          statusCode: 400 /* BAD_REQUEST_400 */,
          body: createStandardError(error.code)
        };
      }
      if (error instanceof Prisma.PrismaClientValidationError) {
        return {
          statusCode: 400 /* BAD_REQUEST_400 */,
          body: {
            message: error.message,
            responseCode: 12 /* INVALID_BODY */
          }
        };
      }
      return {
        statusCode: 500 /* INTERNAL_SERVER_ERROR_500 */,
        body: createStandardError(2 /* INTERNAL_SERVER_ERROR */)
      };
    }
  };
};

// src/utility/attachHandler.ts
var attachHandler = (someNormalHandler) => async (DC, event, context) => {
  let parsedBody = parseEventBody(event.body);
  let queries = event.queryStringParameters;
  let result = await someNormalHandler(DC, parsedBody, queries);
  return {
    ...result,
    body: JSON.stringify(result.body)
  };
};

export {
  hasRequiredFields,
  getAllKeysFromEnum,
  createStandardError,
  errorCatcher,
  attachHandler
};
