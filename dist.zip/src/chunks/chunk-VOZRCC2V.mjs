// src/utility/common.ts
function hasRequiredFields(obj, ...fields) {
  const flatFields = fields.flat();
  return flatFields.every((field) => obj.hasOwnProperty(field));
}
var getAllKeysFromEnum = (enumObject) => {
  return Object.keys(enumObject).filter((key) => !isNaN(Number(enumObject[key]))).map((key) => Number(enumObject[key]));
};

// src/models/enums/roleEnum.ts
var Role = /* @__PURE__ */ ((Role2) => {
  Role2[Role2["User"] = 1] = "User";
  Role2[Role2["Support"] = 2] = "Support";
  Role2[Role2["Admin"] = 4] = "Admin";
  Role2[Role2["SuperAdmin"] = 8] = "SuperAdmin";
  return Role2;
})(Role || {});

// src/models/enums/responseCodeEnum.ts
var ResponseCodeEnum = /* @__PURE__ */ ((ResponseCodeEnum2) => {
  ResponseCodeEnum2[ResponseCodeEnum2["OK"] = 1] = "OK";
  ResponseCodeEnum2[ResponseCodeEnum2["INTERNAL_SERVER_ERROR"] = 2] = "INTERNAL_SERVER_ERROR";
  ResponseCodeEnum2[ResponseCodeEnum2["RESOURCE_NOT_FOUND"] = 3] = "RESOURCE_NOT_FOUND";
  ResponseCodeEnum2[ResponseCodeEnum2["EMAIL_NOT_VALID"] = 4] = "EMAIL_NOT_VALID";
  ResponseCodeEnum2[ResponseCodeEnum2["PHONE_NUMBER_NOT_VALID"] = 5] = "PHONE_NUMBER_NOT_VALID";
  ResponseCodeEnum2[ResponseCodeEnum2["BAD_ADD_USER_REQUEST"] = 6] = "BAD_ADD_USER_REQUEST";
  ResponseCodeEnum2[ResponseCodeEnum2["USER_EMAIL_REQUIRED"] = 7] = "USER_EMAIL_REQUIRED";
  ResponseCodeEnum2[ResponseCodeEnum2["USER_NAME_REQUIRED"] = 8] = "USER_NAME_REQUIRED";
  ResponseCodeEnum2[ResponseCodeEnum2["USER_ROLE_REQUIRED"] = 9] = "USER_ROLE_REQUIRED";
  ResponseCodeEnum2[ResponseCodeEnum2["USER_NAME_MIN_5"] = 10] = "USER_NAME_MIN_5";
  ResponseCodeEnum2[ResponseCodeEnum2["USER_NAME_MAX_15"] = 11] = "USER_NAME_MAX_15";
  ResponseCodeEnum2[ResponseCodeEnum2["INVALID_BODY"] = 12] = "INVALID_BODY";
  ResponseCodeEnum2[ResponseCodeEnum2["ID_IS_REQUIRED"] = 13] = "ID_IS_REQUIRED";
  return ResponseCodeEnum2;
})(ResponseCodeEnum || {});

// src/utility/handlerReturnGenerator.ts
var handlerErrorReturn = (responseCode, extra) => ({
  message: ResponseCodeEnum[responseCode],
  responseCode,
  body: extra ? extra : [].toString()
});

export {
  Role,
  hasRequiredFields,
  getAllKeysFromEnum,
  handlerErrorReturn
};
