import {
  apply_console_logger,
  apply_kms,
  apply_prisma
} from "./chunks/chunk-MLSITODM.mjs";
import {
  routeContainer_default
} from "./chunks/chunk-RJTFKJIV.mjs";
import "./chunks/chunk-SU5NRFYH.mjs";
import "./chunks/chunk-6Y76NDYS.mjs";
import "./chunks/chunk-B5IRZ4AL.mjs";
import {
  handlerErrorReturn
} from "./chunks/chunk-VOZRCC2V.mjs";

// src/index.ts
console.log("first");
var injector = apply_kms(apply_console_logger({}));
var decrypted_env_string = await injector.Cryptography.get_encrypted_environment_variable(
  "ENC_MONGO_DB_URI"
);
if (decrypted_env_string) {
  injector = apply_prisma(injector, decrypted_env_string);
  console.log("second prisma");
}
var handler = async (event, context) => {
  injector.logger.log(
    "event object %S,\n context object %O",
    JSON.stringify(event),
    context
  );
  if (!(event.rawPath in routeContainer_default)) {
    return {
      statusCode: 404,
      body: JSON.stringify(handlerErrorReturn(3 /* RESOURCE_NOT_FOUND */))
    };
  }
  try {
    const result = await routeContainer_default[event.rawPath](injector, event, context);
    return result;
  } catch (error) {
    injector.logger.error("Error handling request:", error);
    return {
      statusCode: 500,
      body: JSON.stringify(handlerErrorReturn(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};
export {
  handler
};
