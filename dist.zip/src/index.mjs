import {
  applyConsoleLogger,
  applyKms,
  applyPrisma
} from "./chunks/chunk-AWVROBPT.mjs";
import {
  routeContainer_default
} from "./chunks/chunk-JFUBAQTG.mjs";
import "./chunks/chunk-XNM33D3Y.mjs";
import "./chunks/chunk-5FQOEDPE.mjs";
import {
  createStandardError
} from "./chunks/chunk-CQZB46HZ.mjs";
import "./chunks/chunk-6FK26I6N.mjs";

// src/index.ts
import { Prisma } from "@prisma/client";
import { ValidationError } from "yup";
var injector = applyKms(applyConsoleLogger({}));
var decryptedEnvString = await injector.cryptography.getEnvironmentVariable(
  "MONGO_DB_URI_ENC"
);
if (decryptedEnvString) {
  injector = applyPrisma(injector, decryptedEnvString);
}
var handler = async (event, context) => {
  injector.logger.log(
    "event object %s,\n context object %O",
    JSON.stringify(event),
    context
  );
  if (!(event.rawPath in routeContainer_default)) {
    return {
      statusCode: 404,
      body: JSON.stringify(createStandardError(3 /* RESOURCE_NOT_FOUND */))
    };
  }
  try {
    const routeHandler = routeContainer_default[event.rawPath];
    const result = await routeHandler(injector, event, context);
    return result;
  } catch (error) {
    injector.logger.log(error, JSON.stringify(error));
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === "P2002") {
        return {
          statusCode: 409 /* CONFLICT_409 */,
          body: JSON.stringify(createStandardError(error.code))
        };
      }
      return {
        statusCode: 400 /* BAD_REQUEST_400 */,
        body: JSON.stringify(createStandardError(error.code))
      };
    }
    if (error instanceof Prisma.PrismaClientValidationError) {
      return {
        statusCode: 400 /* BAD_REQUEST_400 */,
        body: JSON.stringify(createStandardError(12 /* INVALID_BODY */))
      };
    }
    if (error instanceof ValidationError) {
      return {
        statusCode: 400 /* BAD_REQUEST_400 */,
        body: JSON.stringify(createStandardError(parseInt(error.message), error.errors))
      };
    }
    return {
      statusCode: 500 /* INTERNAL_SERVER_ERROR_500 */,
      body: JSON.stringify(createStandardError(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};
export {
  handler
};
